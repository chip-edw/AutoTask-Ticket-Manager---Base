const SubjectExclusions = () => {
  return (
    <div>
      <h2>Subject Exclusions</h2>
      <p>Manage subject keyword exclusions.</p>
    </div>
  );
};

export default SubjectExclusions;
