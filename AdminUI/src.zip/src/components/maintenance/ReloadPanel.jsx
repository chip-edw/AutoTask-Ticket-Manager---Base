const ReloadPanel = () => {
  return (
    <div>
      <h2>Reload Memory</h2>
      <p>Reload in-memory cache from database or external systems.</p>
    </div>
  );
};

export default ReloadPanel;
