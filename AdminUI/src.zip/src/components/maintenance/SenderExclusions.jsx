const SenderExclusions = () => {
  return (
    <div>
      <h2>Sender Exclusions</h2>
      <p>Manage sender email exclusions.</p>
    </div>
  );
};

export default SenderExclusions;
