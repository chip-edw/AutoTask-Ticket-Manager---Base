const SystemStats = () => {
  return (
    <div>
      <h2>System Stats</h2>
      <p>View company counts from AutoTask, Database, and Memory.</p>
    </div>
  );
};

export default SystemStats;
