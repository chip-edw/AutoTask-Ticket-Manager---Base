import { useEffect, useState } from "react";
import { Box, Paper, TextField, Switch, FormControlLabel, Button, Typography } from "@mui/material";
import axios from "axios";

const CompanySettings = () => {
  const [companies, setCompanies] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchCompanySettings();
  }, []);

  const fetchCompanySettings = async () => {
    try {
      const response = await axios.get("/api/maintenance/companysettings"); // Update if your endpoint is different
      setCompanies(response.data);
    } catch (error) {
      console.error("Failed to fetch company settings:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (index, field, value) => {
    const updatedCompanies = [...companies];
    updatedCompanies[index][field] = value;
    setCompanies(updatedCompanies);
  };

  const handleSave = async (company) => {
    try {
      await axios.put("/api/maintenance/companysettings", company); // Update if your save endpoint differs
      alert("Saved successfully!");
    } catch (error) {
      console.error("Failed to save company settings:", error);
      alert("Failed to save changes.");
    }
  };

  if (loading) {
    return <div>Loading Company Settings...</div>;
  }

  return (
    <Box sx={{ maxHeight: "70vh", overflowY: "auto", pr: 2 }}>
      <Typography variant="h4" gutterBottom>Company Settings</Typography>

      {companies.map((company, index) => (
        <Paper key={company.autotaskId} sx={{ mb: 2, p: 2 }}>
          <Typography variant="h6">{company.accountName || "New Company"}</Typography>
          
          <TextField
            label="Account Name"
            value={company.accountName}
            onChange={(e) => handleInputChange(index, "accountName", e.target.value)}
            fullWidth
            margin="normal"
          />

          <TextField
            label="Support Email"
            value={company.supportEmail}
            onChange={(e) => handleInputChange(index, "supportEmail", e.target.value)}
            fullWidth
            margin="normal"
          />

          <FormControlLabel
            control={
              <Switch
                checked={company.enabled}
                onChange={(e) => handleInputChange(index, "enabled", e.target.checked)}
              />
            }
            label="Enabled"
          />

          <FormControlLabel
            control={
              <Switch
                checked={company.enableEmail}
                onChange={(e) => handleInputChange(index, "enableEmail", e.target.checked)}
              />
            }
            label="Enable Email"
          />

          <FormControlLabel
            control={
              <Switch
                checked={company.autoAssign}
                onChange={(e) => handleInputChange(index, "autoAssign", e.target.checked)}
              />
            }
            label="Auto Assign"
          />

          <Box sx={{ mt: 2 }}>
            <Button variant="contained" onClick={() => handleSave(company)}>
              Save Changes
            </Button>
          </Box>
        </Paper>
      ))}
    </Box>
  );
};

export default CompanySettings;
