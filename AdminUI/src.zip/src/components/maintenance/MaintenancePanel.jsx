import { Link, Outlet } from "react-router-dom";

const MaintenancePanel = () => {
  return (
    <div>
      <h1>Admin Maintenance Panel</h1>
      <nav>
        <ul>
          <li><Link to="company-settings">Company Settings</Link></li>
          <li><Link to="system-stats">System Stats</Link></li>
          <li><Link to="subject-exclusions">Subject Exclusions</Link></li>
          <li><Link to="sender-exclusions">Sender Exclusions</Link></li>
          <li><Link to="reload">Reload Memory</Link></li>
        </ul>
      </nav>
      <hr />
      <Outlet />
    </div>
  );
};

export default MaintenancePanel;
