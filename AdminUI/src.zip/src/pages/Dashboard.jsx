function Dashboard() {
  return <h1>Admin Dashboard (Worker Health Overview)</h1>;
}

export default Dashboard;
