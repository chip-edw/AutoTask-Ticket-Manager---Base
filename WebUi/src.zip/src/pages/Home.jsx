function Home() {
  return <h1>Home Page (Welcome to ATTMS)</h1>;
}

export default Home;
