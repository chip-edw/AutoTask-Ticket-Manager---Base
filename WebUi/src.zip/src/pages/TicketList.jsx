function TicketList() {
  return <h1>Ticket List (Open Tickets)</h1>;
}

export default TicketList;
