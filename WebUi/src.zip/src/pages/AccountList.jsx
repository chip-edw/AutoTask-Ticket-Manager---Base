function AccountList() {
  return <h1>Account List (CRM Accounts)</h1>;
}

export default AccountList;
